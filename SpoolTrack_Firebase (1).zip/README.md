# SpoolTrack (Flutter + Firebase) — MVP
**Control de spools por QR** con Firestore y usuarios demo (sin Firebase Auth).

## Firebase
1. Crea proyecto en https://console.firebase.google.com
2. Firestore → colección `users` con 2 documentos:
   - supervisor@demo.com / demo123 / role: supervisor / area: Taller A
   - worker@demo.com / demo123 / role: worker / area: Taller A
3. Project Settings → app Android → descarga `google-services.json`.
4. Opción A (CI): sube `google-services.json` en la **raíz** del repo (privado). El workflow lo moverá a `android/app/`.
5. Opción B (local): `flutter create . --platforms=android` → mueve `google-services.json` a `android/app/`.

## Construcción (CI)
- Sube el repo a GitHub → pestaña **Actions** → *Android APK (Flutter)* → Run workflow → descarga artifact `SpoolTrack-debug-apk`.

## Local
```bash
flutter create . --platforms=android
flutter pub get
flutter build apk --debug
```

Generado: 2025-09-06T18:16:18
